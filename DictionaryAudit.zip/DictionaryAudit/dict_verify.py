class DictVerify:

	def __init__(self):
		pass

	def get_standard(self):
		pass

	def get_input(self):
		pass

	def get_rules(self):
		pass


	def verify(self):
		pass
