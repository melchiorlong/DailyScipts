import openpyxl
from openpyxl import load_workbook

class DictLoad:

	def __init__(self):
		pass

	def excel_load(self):

		pass




	def task_run(self):
		pass




